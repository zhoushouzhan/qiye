<?php
/*
 * @Author: 一品网络技术有限公司
 * @Date: 2022-08-06 08:12:35
 * @LastEditTime: 2023-12-06 17:48:53
 * @FilePath: \web\app\admin\controller\Files.php
 * @Description:
 * 联系QQ:58055648
 * Copyright (c) 2022 by 东海县一品网络技术有限公司, All Rights Reserved.
 */

declare(strict_types=1);

namespace app\admin\controller;



class Files extends Base
{
    protected $table;
    protected function initialize()
    {
        parent::initialize();
        $this->table = new \app\common\model\Files;
    }
    public function index($keyword = '', $page = 1, $isuse = 1)
    {
        $map = [];
        if (!empty($keyword)) {
            $map[] = ['name', 'like', "%{$keyword}%"];
        }
        if (empty($isuse)) {
            $map[] = ['ypcms_id', '=', 0];
        }
        $files_list = $this->table->where($map)->order(['id' => 'DESC'])->paginate(30, false, ['page' => $page]);
        $this->success('附件获取成功', $files_list);
    }

    public function details($id)
    {

        $this->success('获取成功', $this->table::find($id));
    }
    //获取文件列表
    public function getjson($ftype = 0, $page = 1, $keyword = '')
    {
        $map = [];
        if ($ftype) {
            $map[] = ['ftype', 'like', "$ftype%"];
        }
        if (!empty($keyword)) {
            $map[] = ['name', 'like', "%{$keyword}%"];
        }
        //只读取未使用的附件
        $map[] = ['ypcms_id', '=', 0];
        $files_list = $this->table->where($map)->order(['id' => 'DESC'])->paginate(24, false, ['page' => $page]);

        return $files_list;
    }
    public function del($id, $bind = 0)
    {
        if (!$id) {
            return;
        }
        if ($bind == 1) {
            $r = $this->table->save(
                [
                    'ypcms_id' => '',
                    'ypcms_type' => '',
                ],
                ['id' => $id]
            );
            $msg = "取消成功";
        } else {
            $r = $this->table->destroy($id);
            $msg = "删除成功";
        }
        if ($r) {
            $this->success($msg);
        } else {
            $this->error('操作失败');
        }
    }

    public function delete($ids)
    {
        if (!$ids) {
            return 0;
        }
        if (is_array($ids)) {
            $ids = array_map('intval', $ids);
        }
        $rs = $this->table::destroy($ids);
        if ($rs) {
            $this->success("删除成功");
        }
    }
}
