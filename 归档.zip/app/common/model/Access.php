<?php
/*
 * @Author: 一品网络技术有限公司
 * @Date: 2022-09-26 12:25:08
 * @LastEditTime: 2022-09-26 12:25:15
 * @FilePath: \web\app\common\model\Access.php
 * @Description:
 * 联系QQ:58055648
 * Copyright (c) 2022 by 东海县一品网络技术有限公司, All Rights Reserved.
 */

declare(strict_types=1);

namespace app\common\model;

use think\Model;

class Access extends Model
{
    //您的代码
}
