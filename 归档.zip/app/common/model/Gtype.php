<?php
namespace app\common\model;
use think\Model;
class Gtype extends Model {
use \mod\Gtype;
//自定义内容

}
?>