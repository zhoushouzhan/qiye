<?php
namespace app\common\model;
use think\Model;
class Order extends Model {
use \mod\Order;
//自定义内容

}
?>