<?php
namespace app\common\model;
use think\Model;
class Sitepro extends Model {
use \mod\Sitepro;
    //自定义内容
    protected $pk = 'id';
}
?>