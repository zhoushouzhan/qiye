<?php
return [
    'member' => [
        'salt' => 'www.yinpinwangluojishu.com'
    ]
];
