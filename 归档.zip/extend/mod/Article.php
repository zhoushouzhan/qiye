<?php
namespace mod;
trait Article {

}
?>