<?php
namespace mod;
trait Category {

}
?>