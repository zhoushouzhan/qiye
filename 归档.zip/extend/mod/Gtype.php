<?php
namespace mod;
trait Gtype {

}
?>