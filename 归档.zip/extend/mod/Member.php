<?php
namespace mod;
trait Member {

}
?>