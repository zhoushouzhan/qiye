<?php
namespace mod;
trait Order {

}
?>