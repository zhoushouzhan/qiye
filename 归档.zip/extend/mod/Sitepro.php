<?php
namespace mod;
trait Sitepro {

}
?>