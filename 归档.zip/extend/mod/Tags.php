<?php
namespace mod;
trait Tags {

}
?>