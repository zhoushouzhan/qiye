<?php
/*
 * @Author: 一品网络技术有限公司
 * @Date: 2022-08-18 11:44:39
 * @LastEditTime: 2022-08-18 20:50:46
 * @FilePath: \web\extend\yp\Ypexcel.php
 * @Description:
 * 联系QQ:58055648
 * Copyright (c) 2022 by 东海县一品网络技术有限公司, All Rights Reserved.
 */

namespace yp;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Ypexcel
{
    public function toxlsx($header = [], $dataList = [])
    {
        $spreadsheet = new Spreadsheet();

        $sheet = $spreadsheet->getActiveSheet();


        foreach ($header as $k => $v) {
            $colum = $this->getCol($k);
            $sheet->setCellValue($colum . '1', $v['alias']);
        }
        
        foreach ($dataList as $index => $item) {
            foreach ($header as $k => $v) {
                $colum = $this->getCol($k);

                $val = $item[$v['name']];
                if (isset($val['pathinfo'])) {
                    $val = $val['pathinfo'];
                }
                if(is_array($val)){
                    continue;
                }
                $sheet->setCellValue($colum . ($index + 2),  $val);
            }
        }
        header('Content-Type: application/vnd.ms-excel');
        header("Content-Disposition: attachment;filename=" . date("Y-m-d His") . ".xlsx");
        header('Cache-Control: max-age=0');
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);
        exit;
    }
    public function getCol($number = 0)
    {
        $index = 'A';
        for ($i = 1; $i <= $number; ++$i) {
            ++$index;
        }
        return $index;
    }
    public function formxlsx($filepath, $cols)
    {

    }
}
