<?php /*a:1:{s:30:"../view/admin/index\index.html";i:1698719291;}*/ ?>
<!--
 * @Author: 一品网络技术有限公司
 * @Date: 2022-06-21 16:12:37
 * @LastEditTime: 2022-07-14 13:34:42
 * @FilePath: \vite-project\index.html
 * @Description:
 * 联系QQ:58055648
 * Copyright (c) 2022 by 东海县一品网络技术有限公司, All Rights Reserved.
-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" href="/assets/favicon-1cd64782.ico" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
    />

    <title>一品网络管理系统</title>
    <script>
      function diyresponse(data){

        console.log(window.location.href)

       console.log(typeof(data.data.admin.truename))

        return data
      }
    </script>
    <script type="module" crossorigin src="/assets/index-1977bbe8.js"></script>
    <link rel="stylesheet" href="/assets/index-18b61c25.css">
  </head>
  <body>
    <div id="app" class="app"></div>
    
  </body>
</html>
