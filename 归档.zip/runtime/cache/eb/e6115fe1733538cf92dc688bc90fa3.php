<?php
//000000000000
 exit();?>
a:10:{s:2:"id";i:1;s:9:"sitetitle";s:12:"笨鸟先飞";s:7:"siteurl";s:12:"www.qiye.com";s:9:"icpnumber";s:19:"苏ICP备1999996号";s:10:"uploadsize";i:2048;s:8:"filetype";s:7:"jpg,png";s:8:"filesdir";s:6:"images";s:7:"sitekey";s:8:"23452345";s:9:"siteintro";s:7:"5345243";s:4:"logo";i:71;}